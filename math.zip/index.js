export const handler = async (event) => {
    console.log('Math function triggered:', JSON.stringify(event, null, 2));
    
    try {
        const path = event.path;
        const number = parseFloat(event.queryStringParameters?.number);
        
        if (isNaN(number)) {
            return {
                statusCode: 400,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    error: 'Invalid number parameter',
                    message: 'Please provide a valid number',
                    timestamp: new Date().toISOString()
                })
            };
        }
        
        let result;
        let operation;
        
        if (path.includes('/square')) {
            result = number * number;
            operation = 'square';
        } else if (path.includes('/factorial')) {
            if (number < 0 || number > 20) {
                return {
                    statusCode: 400,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        error: 'Invalid input',
                        message: 'Factorial can only be calculated for numbers between 0 and 20',
                        timestamp: new Date().toISOString()
                    })
                };
            }
            result = calculateFactorial(Math.floor(number));
            operation = 'factorial';
        } else {
            return {
                statusCode: 404,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    error: 'Not found',
                    message: 'Math operation not supported',
                    timestamp: new Date().toISOString()
                })
            };
        }
        
        const response = {
            number: number,
            [operation]: result,
            timestamp: new Date().toISOString(),
            functionName: 'my-first-serverless-math',
            region: process.env.AWS_REGION || 'us-east-1'
        };
        
        console.log('Math result:', JSON.stringify(response, null, 2));
        
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
            },
            body: JSON.stringify(response)
        };
        
    } catch (error) {
        console.error('Error in math function:', error);
        
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                error: 'Internal server error',
                message: error.message,
                timestamp: new Date().toISOString()
            })
        };
    }
};

function calculateFactorial(n) {
    if (n === 0 || n === 1) {
        return 1;
    }
    let result = 1;
    for (let i = 2; i <= n; i++) {
        result *= i;
    }
    return result;
}
