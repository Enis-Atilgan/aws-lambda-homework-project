export const handler = async (event) => {
    console.log('Hello function triggered:', JSON.stringify(event, null, 2));
    
    try {
        // Query parametrelerini al
        const name = event.queryStringParameters?.name || 'Dünya';
        
        const response = {
            message: `Merhaba ${name}, bu fonksiyon bulutta çalışıyor!`,
            timestamp: new Date().toISOString(),
            functionName: 'my-first-serverless-hello',
            region: process.env.AWS_REGION || 'us-east-1'
        };
        
        console.log('Response:', JSON.stringify(response, null, 2));
        
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
            },
            body: JSON.stringify(response)
        };
        
    } catch (error) {
        console.error('Error in hello function:', error);
        
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                error: 'Internal server error',
                message: error.message,
                timestamp: new Date().toISOString()
            })
        };
    }
};
